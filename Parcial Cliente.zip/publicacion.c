#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "publicacion.h"
#include "utn.h"
#define QTY 100
#define OCUPADO 0
#define LIBRE 1

static int buscarLugarLibre(Publicacion* array,int limite);
static int proximoId();
/** \brief Inicia el conteo del cliente
 *
 * \param array Publicacion* Trae datos de estructura para pasarelos a la funcion
 * \param limite int Dentro del for va el limite que es hasta donde puede recorrerse
 * \return int retorno al -1
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty = 1;
        }
    }
    return retorno;
}
/** \brief Busca un lugar libre donde ueda ir un nuevo ID
 *
 * \param La funcion recorre el for
 * \param Luego iguala los id para queno haya dos iguales
 * \return retorna en la variable i
 *
 */
int publicacion_buscarPorId(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty == OCUPADO && array[i].idCliente == id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}
/** \brief Da de baja a un cliente
 *
 * \param array Publicacion* Le pasa el array de cliente
 * \param limite int Es hasta donde puede recorrerse
 * \param id int se le pasa el id para la baja
 * \return int retorna en -1 para dar de baja
 *
 */
int publicacion_baja(Publicacion* array,int limite, int id)
{

    int retorno = -1;
    int indice;
    indice = publicacion_buscarPorId(array,limite,id);
    if(indice >= 0)
    {
        retorno = 0;
        array[indice].isEmpty = LIBRE;
    }
    return retorno;
}

/** \brief Da de alta un cliente
 *
 * \param array Publicacion* pasa datos de la estructura
 * \param limite int Indica hasta donde puede llegar
 * \return int retorna distintos return para -1 -2 -3
 *
 */
int publicacion_alta(Publicacion* array,int limite)
{
    int retorno = -1;
    int idCliente;
    int nRubro[200];
    char textoAviso[64];
    int id;
    int indice;

    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        indice = buscarLugarLibre(array,limite);
        if(indice >= 0)
        {
            retorno = -3;
            id = proximoId();
            if(!getValidString("Ingrese ID \n","Error","Overflow", idCliente,50,2))
            {
                retorno = 0;
                strcpy(array[indice].idCliente,idCliente);
                array[indice].idCliente = id;
                array[indice].isEmpty = OCUPADO;

            }
             if(!getValidString("Ingrese numero de rubro \n","Error","Overflow",nRubro,50,2))
            {
                retorno = 0;
                strcpy(array[indice].nRubro,nRubro);
                array[indice].idCliente = id;
                array[indice].isEmpty = OCUPADO;

            }
             if(!getValidString("Ingrese ID \n","Error","Overflow", idCliente,50,2))
            {
                retorno = 0;
                strcpy(array[indice].idCliente,idCliente);
                array[indice].idCliente = id;
                array[indice].isEmpty = OCUPADO;

            }
        }
    }
    return retorno;
}

/** \brief Busca un lugar libre dentro de la funcion
 *
 * \param array Publicacion* busca un lugar libre con los datos del cliente
 * \param limite int Hasta donde puede llegar dentro del for
 * \return int
 *
 */
static int buscarLugarLibre(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty == LIBRE)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


/** \brief recorre para encontrar el proximo id
 *
 * \return int returna en el ultimo id para incrementarlo
 *
 */
 static int proximoId()
{
    static int ultimoId = -1;
    ultimoId++;
    return ultimoId;
}

