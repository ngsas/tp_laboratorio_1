#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cliente.h"
#include "publicacion.h"
#include "utn.h"
#define QTY 100
#define OCUPADO 0
#define LIBRE 1

static int buscarLugarLibre(Cliente* array,int limite);
static int proximoId();

/** \brief Inicia el conteo del cliente
 *
 * \param array Cliente* Trae datos de estructura para pasarelos a la funcion
 * \param limite int Dentro del for va el limite que es hasta donde puede recorrerse
 * \return int retorno al -1
 *
 */
int cliente_init(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty = 1;
        }
    }
    return retorno;
}
/** \brief Busca un lugar libre donde ueda ir un nuevo ID
 *
 * \param La funcion recorre el for
 * \param Luego iguala los id para queno haya dos iguales
 * \return retorna en la variable i
 *
 */
int cliente_buscarPorId(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty == OCUPADO && array[i].idCliente == id)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

/** \brief Da de baja a un cliente
 *
 * \param array Cliente* Le pasa el array de cliente
 * \param limite int Es hasta donde puede recorrerse
 * \param id int se le pasa el id para la baja
 * \return int retorna en -1 para dar de baja
 *
 */
int cliente_baja(Cliente* array,int limite, int id)
{

    int retorno = -1;
    int indice;
    indice = cliente_buscarPorId(array,limite,id);
    if(indice >= 0)
    {
        retorno = 0;
        array[indice].isEmpty = LIBRE;
    }
    return retorno;
}

/** \brief Muestra la lista con los clientes
 *
 * \param En el array se les pasa los datos de la estructura
 * \param E indica hasta donde puede recorrer
 * \return retorna en -1
 *
 */

int cliente_mostrar(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
            {
               printf("\n %s - %d - %d",array[i].nombre,array[i].idCliente,array[i].isEmpty);
            }
        }
    }
    return retorno;
}

/** \brief Da de alta un cliente
 *
 * \param array Cliente* pasa datos de la estructura
 * \param limite int Indica hasta donde puede llegar
 * \return int retorna distintos return para -1 -2 -3
 *
 */
int cliente_alta(Cliente* array,int limite)
{
    int retorno = -1;
    char nombre[50];
    int id;
    int indice;

    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        indice = buscarLugarLibre(array,limite);
        if(indice >= 0)
        {
            retorno = -3;
            id = proximoId();
            if(!getValidString("Ingrese nombre apellido y cuit\n","Error","Overflow", nombre,50,2))
            {
                retorno = 0;
                strcpy(array[indice].nombre,nombre);
                array[indice].idCliente = id;
                array[indice].isEmpty = OCUPADO;

            }
        }
    }
    return retorno;
}


/** \brief Modifica datos del cliente
 *
 * \param array Cliente*pasa datos de estructura
 * \param limite int Limite hasta  donde puede ir
 * \param id int id como dato para moificar del cliente
 * \return int retorna -2 y-1
 *
 */
int cliente_modificacion(Cliente* array,int limite, int id)
{
    int retorno = -1;
    int indice;
    char nombre[50];
    indice = cliente_buscarPorId(array,limite,id);
    if(indice >= 0)
    {
        retorno = -2;
        if(!getValidString("Nombre?","Error","Overflow", nombre,50,2))
        {
            retorno = 0;
            strcpy(array[indice].nombre,nombre);
        }
    }
    return retorno;
}


/** \brief Busca un lugar libre dentro de la funcion
 *
 * \param array Cliente* busca un lugar libre con los datos del cliente
 * \param limite int Hasta donde puede llegar dentro del for
 * \return int
 *
 */
static int buscarLugarLibre(Cliente* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty == LIBRE)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


/** \brief recorre para encontrar el proximo id
 *
 * \return int returna en el ultimo id para incrementarlo
 *
 */
static int proximoId()
{
    static int ultimoId = -1;
    ultimoId++;
    return ultimoId;
}



/** \brief esta funcion ordena datos del cliente
 *
 * \param array Cliente* se le pasan datos de la estructura
 * \param limite int Hasta ddonde puede recorrer
 * \param orden int parametro para ordenar los lugares
 * \return int -1  y en 0
 *
 */
int cliente_ordenar(Cliente* array,int limite, int orden)
{
    int retorno = -1;
    int flagSwap;
    int i;
    Cliente auxiliar;

    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                    if(array[i].isEmpty == OCUPADO && array[i+1].isEmpty == OCUPADO )
                    {
                        if((strcmp(array[i].nombre,array[i+1].nombre) > 0 && !orden) || (strcmp(array[i].nombre,array[i+1].nombre) < 0 && orden))
                        {
                            auxiliar = array[i];
                            array[i] = array[i+1];
                            array[i+1] = auxiliar;
                            flagSwap = 1;
                        }
                    }
            }
        }while(flagSwap);
    }

    return retorno;
}
