#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "publicacion.h"
#include "utn.h"
#define QTY 100

int main()
{
    Cliente array[QTY];
    int menu;
    int auxiliarId;

    cliente_init(array,QTY);
    do
    {
        getValidInt("\n1.Alta de cliente\n2.Modificar datos de cliente\n3.Baja de cliente\n4.Publicar\n5.Ordenar\n7.Imprimir clientes\n8.Imprimir publicaciones\n9.Salir\n","\nNo valida\n",&menu,1,9,1);
        switch(menu)
        {
            case 1:
                cliente_alta(array,QTY);
                break;
             case 2:
                getValidInt("Ingrese ID","\nNumero valida\n",&auxiliarId,0,200,2);
                cliente_modificacion(array,QTY,auxiliarId);
                break;
            case 3:
                getValidInt("Ingrese ID","\nNumero valida\n",&auxiliarId,0,200,2);
                cliente_baja(array,QTY,auxiliarId);
                break;
            case 4:
                publicacion_alta(array,QTY);
                break;
            case 5:
                cliente_ordenar(array,QTY,0);
                break;
            case 6:
                break;
            case 7:
                cliente_mostrar(array,QTY);
                break;
            case 8:
                break;
        }

    }while(menu != 9);

    return 0;
}
